var config = {
    server: {
      id: "environment",
      name: "demo",
      host: "192.168.1.55",
      internalPort: "3010",
      protocol : "http",
      web_uri: "http://192.168.1.55:3010"
    },
    
    logging : {
      level : 'debug', //Can be 'debug' , 'warn', 'info', 'error'
      loggers : {
        graylog : { type :'graylog' , host : '192.168.1.55' , port : 12201 },
        local : {type: 'local' }
      }
    },
    database: {
      client:'mysql',
      connection: {
        host:'localhost',
        port:'3306',
        user: 'root',
        password: '',
        database: 'cns',
        charset: 'utf8'
      }
    },
    session: {
      secret: 'A Super Special And Fantastic Secret!'
    },
    webUri: 'http://192.168.1.55:3010',
    web_name: "Cns",
    Authorkey : "Ak12mr27Xwg@d89ul",
};

module.exports = config;

