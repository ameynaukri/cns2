/**
 * Module dependencies
 */
var controller = require('../controllers/client.controller');

/**
 * the new Router exposed in express 4
 * the indexRouter handles all requests to the `/` path
 */
module.exports = function(router) {
  /**
   * this accepts all request methods to the `/` path
   */

  
 /* router.route('/client/:clientId') 
    .put(controller.updateClient)   

  router.route('/client/delete/:clientId/:orgId')
    .delete(controller.deleteClient);

  router.route('/get/Cnsclients')
    .get(controller.getClient);*/

  /*router.route('/user/client/:clientId/:orgId')
      .get(controller.listClient);*/
  router.route('/user/Cnsclient')
      .get(controller.listClient);

 /* router.route('/client/keyword/:id')
      .post(controller.searchByKeyword);*/


}
